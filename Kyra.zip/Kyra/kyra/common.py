"""Helpers partagés : chemins data/*.json, JSON I/O, admin par défaut, hash de mots de passe."""

import functools

import hashlib
import hmac
import json
import os

from flask import redirect, session, url_for
from werkzeug.security import check_password_hash

from kyra.db import init_db

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")

USERS_FILE = os.path.join(DATA_DIR, "users.json")
DOCUMENTS_FILE = os.path.join(DATA_DIR, "documents.json")
TAGS_FILE = os.path.join(DATA_DIR, "tags.json")
API_KEYS_FILE = os.path.join(DATA_DIR, "api_keys.json")
CR_SUIVI_FILE = os.path.join(DATA_DIR, "cr_suivi.json")

DEFAULT_ADMIN_USER = "admin"
DEFAULT_ADMIN_PASSWORD = "admin"
DEFAULT_RESET_PASSWORD = "KYRA2026!"


def ensure_data_dir():
    """Crée les répertoires data/ et uploads/ si nécessaire."""
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)


def load_json(path, default=None):
    """Charge un fichier JSON, retourne `default` si absent/corrompu."""
    if default is None:
        default = {}
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return default


def save_json(path, data):
    """Écrit des données dans un fichier JSON."""
    ensure_data_dir()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def hash_password(password):
    """Retourne le sha256 hexadécimal du mot de passe."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _verify_scrypt_hex(password, stored):
    """Vérifie un hash au format « scrypt:N:r:p$sel$hash_hex » (hash hexadécimal)."""
    try:
        params, salt, hash_hex = stored.split("$", 2)
        _, n, r, p = params.split(":")
        derived = hashlib.scrypt(
            password.encode("utf-8"),
            salt=salt.encode("utf-8"),
            n=int(n),
            r=int(r),
            p=int(p),
            dklen=len(bytes.fromhex(hash_hex)),
        )
        return hmac.compare_digest(derived.hex(), hash_hex.lower())
    except (ValueError, TypeError):
        return False


def verify_password(password, stored):
    """Vérifie un mot de passe : accepte un hash Werkzeug (scrypt/pbkdf2),
    un hash scrypt hexadécimal « scrypt:N:r:p$sel$hash_hex »,
    un hash sha256 ou un mot de passe en clair."""
    if not isinstance(stored, str):
        return False
    if stored == password:  # tolère le stockage en clair
        return True
    if stored.startswith("scrypt:") and stored.count("$") == 2:
        return _verify_scrypt_hex(password, stored)
    if stored.startswith("scrypt:") or stored.startswith("pbkdf2:"):
        try:
            return check_password_hash(stored, password)
        except ValueError:
            return False
    return stored.lower() == hash_password(password)


def ensure_default_admin():
    """Délègue à kyra.db.init_db() : création de la table users,
    migration de users.json et garantie du compte admin par défaut."""
    init_db()


def login_required(view):
    """Décorateur : exige session['user'], sinon redirige vers /login."""
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)

    return wrapped
