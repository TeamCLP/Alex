"""Blueprint de gestion documentaire : /documents (upload, liste, suppression)."""

import os
import time
from datetime import date

from flask import Blueprint, current_app, flash, redirect, render_template, request, url_for
from werkzeug.utils import secure_filename

from kyra.common import DOCUMENTS_FILE, UPLOAD_DIR, ensure_data_dir, load_json, save_json

documents_bp = Blueprint("documents", __name__)


def _next_id(documents):
    return max((int(k) for k in documents.keys()), default=0) + 1


@documents_bp.route("/documents", methods=["GET"])
def documents():
    ensure_data_dir()
    docs = load_json(DOCUMENTS_FILE, default={})
    return render_template("documents.html", documents=docs)


@documents_bp.post("/documents")
def documents_upload():
    ensure_data_dir()
    file = request.files.get("file")
    if not file or not file.filename:
        flash("Aucun fichier sélectionné.", "error")
        return redirect(url_for("documents.documents"))

    filename = secure_filename(file.filename)
    dest = os.path.join(UPLOAD_DIR, filename)
    counter = 1
    while os.path.exists(dest):
        root, ext = os.path.splitext(filename)
        dest = os.path.join(UPLOAD_DIR, "{}_{}".format(root, counter) + ext)
        counter += 1
    file.save(dest)

    docs = load_json(DOCUMENTS_FILE, default={})
    doc_id = str(_next_id(docs))
    docs[doc_id] = {
        "filename": os.path.basename(dest),
        "original_name": file.filename,
        "uploaded_by": request.form.get("username", "inconnu"),
        "uploaded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "size": os.path.getsize(dest),
    }
    save_json(DOCUMENTS_FILE, docs)
    flash("Document téléversé.", "success")
    return redirect(url_for("documents.documents"))


@documents_bp.post("/documents/delete")
def documents_delete():
    doc_id = request.form.get("doc_id", "")
    docs = load_json(DOCUMENTS_FILE, default={})
    doc = docs.pop(doc_id, None)
    if doc is None:
        flash("Document introuvable.", "error")
    else:
        path = os.path.join(UPLOAD_DIR, doc.get("filename", ""))
        if os.path.isfile(path):
            os.remove(path)
        save_json(DOCUMENTS_FILE, docs)
        flash("Document supprimé.", "success")
    return redirect(url_for("documents.documents"))
