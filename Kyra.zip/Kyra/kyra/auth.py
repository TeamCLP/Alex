"""Blueprint d'authentification : /login et /logout."""

from flask import Blueprint, flash, redirect, render_template, request, url_for

from kyra.common import ensure_default_admin, verify_password
from kyra.db import get_user

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    ensure_default_admin()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_user(username)
        stored = user.get("password", "") if user else ""
        if user and verify_password(password, stored):
            from flask import session
            session["user"] = username
            session["role"] = user.get("role", "user")
            return redirect(url_for("index"))
        flash("Identifiants invalides.", "error")
    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    from flask import session
    session.pop("user", None)
    session.pop("role", None)
    return redirect(url_for("index"))
