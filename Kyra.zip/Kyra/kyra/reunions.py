"""Blueprint réunions : upload de fichier, CR via Kyber et historique."""

import json
import os
import re
import zipfile
from datetime import datetime
from xml.etree import ElementTree

import requests
from flask import (
    Blueprint,
    current_app,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

from .common import UPLOAD_DIR, login_required, load_json, save_json
from .db import get_prompt
from .kyber import (
    KYBER_INVOKE_URL,
    KYBER_PROXY,
    KYBER_VERIFY_SSL,
    _load_kyber_key,
    _request_with_ssl_fallback,
)

reunions_bp = Blueprint("reunions", __name__)

CR_SUIVI_FILE = os.path.join("data", "cr_suivi.json")


def _load_cr_suivi():
    """Charge l'historique des CR depuis data/cr_suivi.json."""
    if os.path.exists(CR_SUIVI_FILE):
        try:
            with open(CR_SUIVI_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return []
    return []


def _save_cr_suivi(entrees):
    """Écrit l'historique des CR dans data/cr_suivi.json."""
    os.makedirs(os.path.dirname(CR_SUIVI_FILE) or ".", exist_ok=True)
    with open(CR_SUIVI_FILE, "w", encoding="utf-8") as f:
        json.dump(entrees, f, ensure_ascii=False, indent=2)


def _archiver(entree):
    """Ajoute une entrée à l'historique des CR."""
    entrees = _load_cr_suivi()
    entrees.append(entree)
    _save_cr_suivi(entrees)


def _prompt_cr_reunion():
    """Lit le prompt « CR Reunion » en base, avec repli raisonnable."""
    try:
        prompt = get_prompt("CR Reunion")
    except Exception as exc:
        current_app.logger.warning("Impossible de lire le prompt « CR Reunion » : %s", exc)
        prompt = None
    if isinstance(prompt, dict):
        contenu = prompt.get("contenu") or prompt.get("texte") or ""
        if contenu:
            return contenu
    if isinstance(prompt, str) and prompt.strip():
        return prompt.strip()
    return "Génère un compte rendu structuré de réunion à partir de ce document."


def _extraire_reponse(payload):
    """Extrait le texte de la réponse Kyber quel que soit le format renvoyé."""
    if not isinstance(payload, dict):
        return json.dumps(payload, ensure_ascii=False)
    return (
        payload.get("response")
        or payload.get("message")
        or payload.get("answer")
        or (
            payload.get("choices", [{}])[0].get("text")
            if isinstance(payload.get("choices"), list) and payload["choices"]
            else None
        )
        or json.dumps(payload, ensure_ascii=False)
    )


def _extraire_texte_docx(stream):
    """Extrait le texte d'un .docx (zip + XML Word) en pur Python."""
    with zipfile.ZipFile(stream) as zf:
        with zf.open("word/document.xml") as fh:
            arbre = ElementTree.parse(fh)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphes = []
    for paragraphe in arbre.iter("{%s}p" % ns["w"]):
        texte = "".join(n.text or "" for n in paragraphe.iter("{%s}t" % ns["w"]))
        if texte.strip():
            paragraphes.append(texte.strip())
    return "\n".join(paragraphes)


def _extraire_texte_fichier(fichier):
    """Extrait le texte d'un fichier uploadé (.docx ou .txt). Retourne '' si échec."""
    fichier.stream.seek(0)
    try:
        nom = (fichier.filename or "").lower()
        if nom.endswith(".docx"):
            return _extraire_texte_docx(fichier.stream)
        brut = fichier.stream.read()
        return brut.decode("utf-8", errors="replace")
    except Exception as exc:
        current_app.logger.warning("Extraction du texte impossible (%s) : %s", fichier.filename, exc)
        return ""
    finally:
        fichier.stream.seek(0)


def _appeler_kyber_avec_fichier(fichier):
    """Envoie un POST JSON {"message": prompt + texte extrait du fichier} à Kyber.
    Retourne (texte, erreur)."""
    if not KYBER_INVOKE_URL:
        return None, "Kyber non configuré (URL manquante)."

    proxies = {"http": KYBER_PROXY, "https": KYBER_PROXY} if KYBER_PROXY else None
    headers = {"Content-Type": "application/json"}
    key = _load_kyber_key()
    if key:
        headers["Authorization"] = f"Bearer {key}"

    prompt = _prompt_cr_reunion()
    texte = _extraire_texte_fichier(fichier)
    if texte.strip():
        message = f"{prompt}\n\n---\n\n{texte}"
    else:
        message = prompt

    try:
        resp = _request_with_ssl_fallback(
            "POST",
            KYBER_INVOKE_URL,
            json={"message": message},
            headers=headers,
            proxies=proxies,
            timeout=120,
            verify=KYBER_VERIFY_SSL,
        )
        resp.raise_for_status()
        try:
            payload = resp.json()
        except ValueError:
            return resp.text, None
        return _extraire_reponse(payload), None
    except requests.RequestException as exc:
        resp = getattr(exc, "response", None)
        if resp is not None:
            current_app.logger.error(
                "Erreur invocation Kyber (réunions) : %s — corps de la réponse : %s",
                exc,
                resp.text,
            )
        else:
            current_app.logger.error("Erreur invocation Kyber (réunions) : %s", exc)
        return None, f"Appel à Kyber impossible : {exc}"


@reunions_bp.route("/reunions", methods=["GET", "POST"])
@login_required
def reunions():
    """Page des CR de réunion : upload d'un fichier envoyé à Kyber."""
    if request.method == "POST":
        fichier = request.files.get("fichier")
        if not fichier or not fichier.filename:
            flash("Veuillez sélectionner un fichier.", "error")
            return redirect(url_for("reunions.reunions"))

        reponse_ia, erreur = _appeler_kyber_avec_fichier(fichier)
        if erreur:
            flash(erreur, "error")
            return redirect(url_for("reunions.reunions"))

        _archiver({
            "date": datetime.now().isoformat(timespec="seconds"),
            "fichier": fichier.filename,
            "reponse": reponse_ia,
        })
        flash("Compte-rendu généré et archivé.", "success")
        return render_template("reunion.html", reponse_ia=reponse_ia, tags=load_json("tags.json"))

    return render_template("reunion.html", tags=load_json("tags.json"))


@reunions_bp.route("/reunion/api", methods=["POST"])
@login_required
def reunion_api():
    """Version JSON : envoie le fichier lui-même (multipart, champ 'file')
    à Kyber avec le prompt « CR Reunion » en champ 'message'."""
    fichier = request.files.get("file") or request.files.get("fichier")
    if not fichier or not fichier.filename:
        return jsonify({"error": "Fichier manquant (champ 'file')."}), 400

    reponse_ia, erreur = _appeler_kyber_avec_fichier(fichier)
    if erreur:
        return jsonify({"error": erreur}), 502

    return jsonify({"reponse_ia": reponse_ia})


@reunions_bp.route("/historique")
@login_required
def historique():
    """Affiche l'historique des CR archivés."""
    entrees = _load_cr_suivi()
    return render_template("historique.html", entrees=entrees)
