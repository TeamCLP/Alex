"""Blueprint Kyber : interface chatbot et invocation de l'API distante."""

import json
import os

import certifi
import requests
from flask import Blueprint, Response, render_template, request, jsonify, current_app, send_from_directory

from .common import login_required
from .db import get_api_key, get_default_prompt, save_prompt

kyber_bp = Blueprint("kyber", __name__)

KYBER_WIDGET_URL = os.environ.get(
    "KYBER_WIDGET_URL",
    "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca/api/v1/deploy/81cf2da7-bdfb-47c6-96e5-f0601f16a0d8/widget.js",
)
API_KEYS_PATH = os.environ.get(
    "API_KEYS_PATH",
    os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "data", "api_keys.json")),
)


def _load_kyber_key():
    """Retourne la clé personnelle Kyber (table api_keys, repli sur data/api_keys.json)."""
    try:
        key = get_api_key("kyber")
    except Exception as exc:
        current_app.logger.warning("Impossible de lire la clé Kyber en base : %s", exc)
        key = None
    if key:
        return key
    # Repli : ancien stockage fichier
    try:
        with open(API_KEYS_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("kyber") or None
    except (OSError, ValueError) as exc:
        current_app.logger.warning("Impossible de lire la clé Kyber (fichier) : %s", exc)
        return None


@kyber_bp.app_context_processor
def _inject_kyber_widget_key():
    return {"kyber_widget_key": _load_kyber_key()}
KYBER_INVOKE_URL = os.environ.get(
    "KYBER_INVOKE_URL",
    "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca/api/v1/deploy/81cf2da7-bdfb-47c6-96e5-f0601f16a0d8/invoke",
)
KYBER_INVOKE_FIELD = os.environ.get("KYBER_INVOKE_FIELD", "message")  # champ attendu par l'API Kyber
KYBER_PROXY = os.environ.get("KYBER_PROXY")  # ex: "http://proxy:8080"
KYBER_VERIFY_SSL = os.environ.get("KYBER_VERIFY_SSL", "1").lower() not in ("0", "false", "no")


def _request_with_ssl_fallback(method, url, **kwargs):
    """Appel HTTP robuste : système -> certifi -> sans SSL ni proxy.

    Étapes :
      1. appel normal (magasin système) ;
      2. nouvelle tentative avec le bundle certifi (la CA d'entreprise
         manque souvent du magasin système) ;
      3. dernier repli : verify=False ET proxies désactivés, sauf si
         KYBER_STRICT_SSL=1.

    Chaque étape intercepte TOUTE RequestException (pas seulement
    SSLError) afin de révéler le vrai point de blocage (proxy,
    connexion...) dans les logs.
    """
    strict = os.environ.get("KYBER_STRICT_SSL", "0").lower() in ("1", "true", "yes")

    # Étape 1 : magasin système
    try:
        return requests.request(method, url, **kwargs)
    except requests.RequestException as sys_exc:
        current_app.logger.warning(
            "[kyber] étape 1/3 échec (magasin système) : %s", sys_exc
        )

    # Étape 2 : bundle certifi
    try:
        current_app.logger.warning(
            "[kyber] étape 2/3 nouvelle tentative avec le bundle certifi"
        )
        kwargs["verify"] = certifi.where()
        return requests.request(method, url, **kwargs)
    except requests.RequestException as certifi_exc:
        current_app.logger.warning(
            "[kyber] étape 2/3 échec (certifi) : %s", certifi_exc
        )

    # Étape 3 : dernier repli, sans SSL ni proxy
    if strict:
        raise
    current_app.logger.warning(
        "[kyber] étape 3/3 dernier repli : verify=False et proxies désactivés. "
        "Définir REQUESTS_CA_BUNDLE vers le bundle CA d'entreprise, ou "
        "KYBER_STRICT_SSL=1 pour désactiver ce repli."
    )
    kwargs["verify"] = False
    kwargs["proxies"] = {"http": None, "https": None, "all": None}
    return requests.request(method, url, **kwargs)


@kyber_bp.route("/kyberbot")
@login_required
def kyberbot():
    widget_url = request.args.get("widget_url") or KYBER_WIDGET_URL
    key = _load_kyber_key()
    if key and "?key=" not in widget_url:
        widget_url = f"{widget_url}?key={key}"
    return render_template("kyberbot.html", widget_url=widget_url)


@kyber_bp.route("/kyber/widget.js")
def widget_js():
    static_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "static"))
    widget_path = os.path.join(static_dir, "kyber_widget.js")
    if os.path.isfile(widget_path):
        return send_from_directory(
            static_dir,
            "kyber_widget.js",
            mimetype="text/javascript",
        )
    if not KYBER_WIDGET_URL:
        return jsonify({"error": "KYBER_WIDGET_URL non configuré."}), 404
    try:
        proxies = {"http": KYBER_PROXY, "https": KYBER_PROXY} if KYBER_PROXY else None
        resp = _request_with_ssl_fallback(
            "GET", KYBER_WIDGET_URL, proxies=proxies, timeout=30, verify=KYBER_VERIFY_SSL
        )
        resp.raise_for_status()
    except requests.RequestException as exc:
        current_app.logger.error("Erreur récupération widget Kyber : %s", exc)
        return jsonify({"error": f"Erreur lors de la récupération du widget : {exc}"}), 502
    return Response(resp.content, mimetype="text/javascript")


@kyber_bp.route("/kyber/invoke", methods=["POST"])
@login_required
def invoke():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("prompt") or data.get("message") or "").strip()
    if not prompt:
        # Aucun prompt fourni : on utilise le prompt par défaut stocké en base
        try:
            prompt = get_default_prompt() or ""
        except Exception as exc:
            current_app.logger.warning("Impossible de lire le prompt par défaut : %s", exc)
            prompt = ""
        if not prompt:
            return jsonify({"error": "Prompt manquant."}), 400

    # Identifiant du prompt (champ 'nom'), repli sur 'defaut'
    nom = data.get("nom") or "defaut"
    try:
        save_prompt(nom, prompt)
    except Exception as exc:
        current_app.logger.warning("Impossible d'enregistrer le prompt %r en base : %s", nom, exc)

    invoke_url = KYBER_INVOKE_URL
    if not invoke_url:
        return jsonify({"error": "KYBER_INVOKE_URL non configuré."}), 500

    kyber_key = _load_kyber_key()
    if not kyber_key:
        return jsonify(
            {"error": "Aucune clé Kyber configurée (champ 'kyber' de data/api_keys.json) : impossible d'appeler l'API."}
        ), 401

    proxies = {"http": KYBER_PROXY, "https": KYBER_PROXY} if KYBER_PROXY else None

    # Payload : champ principal configurable + variantes usuelles en repli.
    # Une 422 (Unprocessable Entity) signifie que le schéma JSON ne correspond
    # pas : on tente successivement les champs les plus courants, à plat puis
    # imbriqués (les endpoints /invoke de type LangServe attendent
    # {"input": {"champ": "..."}} et non un champ plat).
    field_candidates = [KYBER_INVOKE_FIELD]
    for candidate in ("message", "prompt", "query", "input", "text", "question"):
        if candidate not in field_candidates:
            field_candidates.append(candidate)

    headers = {"Authorization": f"Bearer {kyber_key}"}

    resp = None
    last_error = None
    payloads = []
    for field in field_candidates:
        payloads.append({field: prompt})
        payloads.append({"input": {field: prompt}})
    payloads.append({"input": prompt})

    resp = None
    last_error = None
    for payload in payloads:
        try:
            resp = _request_with_ssl_fallback(
                "POST",
                invoke_url,
                json=payload,
                headers=headers,
                proxies=proxies,
                timeout=120,
                verify=KYBER_VERIFY_SSL,
            )
            if resp.status_code == 422:
                current_app.logger.warning(
                    "[kyber] 422 avec le payload %r : %s",
                    list(payload.keys()),
                    resp.text[:500],
                )
                last_error = f"payload {list(payload.keys())} refusé : {resp.text[:200]}"
                continue
            break
        except requests.RequestException as exc:
            last_error = exc
            break

    if resp is None or resp.status_code == 422:
        return jsonify(
            {"error": f"Kyber a refusé la requête (422). Détail : {last_error}"}
        ), 502

    try:
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as exc:
        current_app.logger.exception("Erreur invocation Kyber : %s", exc)
        hint = ""
        if isinstance(exc, requests.exceptions.SSLError):
            hint = (
                " (indice : certificat de la CA d'entreprise manquant ; définir "
                "REQUESTS_CA_BUNDLE pour pointer vers le bundle CA, un repli certifi "
                "a déjà été tenté)"
            )
        return jsonify({"error": f"Erreur lors de l'appel à Kyber : {exc}{hint}"}), 502
    except ValueError as exc:
        current_app.logger.exception("Réponse non-JSON de Kyber (décodage impossible)")
        return jsonify({"error": "Réponse invalide (non-JSON) renvoyée par Kyber."}), 502

    reply = (
        payload.get("content")
        or payload.get("reply")
        or payload.get("response")
        or ""
    )
    if not reply:
        current_app.logger.warning(
            "[kyber] réponse sans content/reply/response : statut HTTP=%s, "
            "corps brut=%r, clés JSON=%s",
            resp.status_code,
            resp.text[:500],
            list(payload.keys()) if isinstance(payload, dict) else type(payload).__name__,
        )
        return jsonify({"error": "Réponse vide de Kyber."}), 502

    return jsonify({"reply": reply})
