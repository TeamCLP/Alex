"""Blueprint d'administration des comptes : /admin."""

import os

from flask import Blueprint, flash, jsonify, redirect, render_template, request, url_for

from kyra import db
from kyra.common import (
    DATA_DIR,
    DEFAULT_RESET_PASSWORD,
    ensure_default_admin,
    hash_password,
    load_json,
    login_required,
    save_json,
)

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/admin")
def admin():
    ensure_default_admin()
    users = db.get_users()
    return render_template("admin.html", users=users)


@admin_bp.post("/admin/add")
def admin_add():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if not username or not password:
        flash("Nom d'utilisateur et mot de passe requis.", "error")
    else:
        if db.user_exists(username):
            flash("Ce compte existe déjà.", "error")
        else:
            db.create_user(username, hash_password(password), "user")
            flash("Compte créé.", "success")
    return redirect(url_for("admin.admin"))


@admin_bp.post("/admin/edit")
def admin_edit():
    original_username = request.form.get("original_username", "").strip() or request.form.get("username", "").strip()
    new_username = request.form.get("username", "").strip()
    if not original_username or not db.user_exists(original_username):
        flash("Compte introuvable.", "error")
    else:
        role = request.form.get("role", "user")
        if new_username and new_username != original_username:
            if db.user_exists(new_username):
                flash("Ce compte existe déjà.", "error")
            else:
                db.rename_user(original_username, new_username)
                db.update_user(new_username, role=role)
                flash("Compte modifié.", "success")
        else:
            db.update_user(original_username, role=role)
            flash("Compte modifié.", "success")
    return redirect(url_for("admin.admin"))


@admin_bp.post("/admin/delete")
def admin_delete():
    username = request.form.get("username", "").strip()
    if username == "admin":
        flash("Impossible de supprimer le compte admin.", "error")
    elif not db.user_exists(username):
        flash("Compte introuvable.", "error")
    else:
        db.delete_user(username)
        flash("Compte supprimé.", "success")
    return redirect(url_for("admin.admin"))


@admin_bp.post("/admin/reset_password")
def admin_reset_password():
    username = request.form.get("username", "").strip()
    if not db.user_exists(username):
        flash("Compte introuvable.", "error")
    else:
        db.update_user(username, password_hash=hash_password(DEFAULT_RESET_PASSWORD))
        flash("Mot de passe réinitialisé.", "success")
    return redirect(url_for("admin.admin"))


@admin_bp.route("/admin/api_keys", methods=["GET", "POST"])
@login_required
def admin_api_keys():
    keys = db.all_api_keys()
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        service = (data.get("service") or "").strip()
        key = (data.get("key") or "").strip()
        if not service or service == "kyber":
            return jsonify({"ok": False, "error": "Service invalide."}), 400
        if not key:
            return jsonify({"ok": False, "error": "Clé API requise."}), 400
        db.set_api_key(service, key)
        return jsonify({"ok": True, "api_keys": db.all_api_keys()})
    return jsonify({"ok": True, "api_keys": keys})


@admin_bp.route("/admin/api_keys/<service>", methods=["DELETE"])
@login_required
def admin_api_keys_delete(service):
    if service == "kyber":
        return jsonify({"ok": False, "error": "Impossible de supprimer le service kyber."}), 400
    keys = db.all_api_keys()
    if service not in keys:
        return jsonify({"ok": False, "error": "Service introuvable."}), 404
    db.delete_api_key(service)
    return jsonify({"ok": True, "api_keys": db.all_api_keys()})


@admin_bp.route("/admin/prompts", methods=["GET", "POST"])
@login_required
def admin_prompts():
    if request.method == "POST":
        data = request.get_json(silent=True) or request.form.to_dict()
        nom = (data.get("nom") or "").strip()
        contenu = (data.get("contenu") or "").strip()
        if not nom or not contenu:
            return jsonify({"ok": False, "error": "Nom et contenu requis."}), 400
        prompt = db.save_prompt(nom, contenu)
        return jsonify({"ok": True, "prompt": prompt, "prompts": db.all_prompts()})
    return jsonify({"ok": True, "prompts": db.all_prompts()})


@admin_bp.route("/admin/prompts/<nom>", methods=["GET", "DELETE"])
@login_required
def admin_prompt_detail(nom):
    prompt = db.get_prompt(nom)
    if not prompt:
        return jsonify({"ok": False, "error": "Prompt introuvable."}), 404
    if request.method == "DELETE":
        db.delete_prompt(nom)
        return jsonify({"ok": True, "prompts": db.all_prompts()})
    return jsonify({"ok": True, "prompt": prompt})


@admin_bp.route("/admin/prompt_cr", methods=["GET", "POST"])
@login_required
def admin_prompt_cr():
    path = os.path.join(DATA_DIR, "prompt_cr.json")
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        prompt = (data.get("prompt_cr") or "").strip()
        if not prompt:
            return jsonify({"ok": False, "error": "Prompt requis."}), 400
        save_json(path, {"prompt_cr": prompt})
        return jsonify({"ok": True, "prompt_cr": prompt})
    stored = load_json(path, default={})
    return jsonify({"ok": True, "prompt_cr": stored.get("prompt_cr", "")})
