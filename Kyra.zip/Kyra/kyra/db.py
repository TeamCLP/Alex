"""Accès SQLite pour la gestion des utilisateurs (data/kyra.db)."""

import json
import os
import sqlite3
import threading

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "kyra.db")
USERS_JSON = os.path.join(os.path.dirname(DB_PATH), "users.json")
API_KEYS_JSON = os.path.join(os.path.dirname(DB_PATH), "api_keys.json")

_lock = threading.Lock()


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Crée la table users si nécessaire et migre depuis users.json si vide."""
    with _lock, get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user'
            )
            """
        )
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if count == 0:
            _migrate_from_json(conn)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS api_keys (
                service TEXT PRIMARY KEY,
                key TEXT
            )
            """
        )
        _migrate_api_keys_from_json(conn)
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS prompts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT UNIQUE NOT NULL,
                contenu TEXT NOT NULL,
                date TEXT
            )
            """
        )


def _migrate_from_json(conn):
    if not os.path.exists(USERS_JSON):
        return
    try:
        with open(USERS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return
    # formats acceptés : liste d'objets ou dict {username: {...}}
    if isinstance(data, dict):
        items = [{"username": k, **v} for k, v in data.items()]
    else:
        items = data
    for u in items:
        username = u.get("username") or u.get("user")
        if not username:
            continue
        conn.execute(
            "INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, u.get("password", u.get("password_hash", "")), u.get("role", "user")),
        )


def _migrate_api_keys_from_json(conn):
    """Importe data/api_keys.json dans la table api_keys (une seule fois)."""
    if not os.path.exists(API_KEYS_JSON):
        return
    try:
        with open(API_KEYS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return
    if not isinstance(data, dict):
        return
    for service, key in data.items():
        if isinstance(key, dict):
            key = key.get("key") or key.get("value")
        if not service or not key:
            continue
        conn.execute(
            "INSERT OR IGNORE INTO api_keys (service, key) VALUES (?, ?)",
            (service, str(key)),
        )


def all_api_keys():
    with get_connection() as conn:
        rows = conn.execute("SELECT service, key FROM api_keys ORDER BY service").fetchall()
    return [dict(r) for r in rows]


def get_api_key(service):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT key FROM api_keys WHERE service = ?", (service,)
        ).fetchone()
    return row["key"] if row else None


def set_api_key(service, key):
    with _lock, get_connection() as conn:
        conn.execute(
            """
            INSERT INTO api_keys (service, key) VALUES (?, ?)
            ON CONFLICT(service) DO UPDATE SET key = excluded.key
            """,
            (service, key),
        )
    return get_api_key(service)


def save_prompt(nom, contenu):
    """Insère ou met à jour un prompt identifié par son nom."""
    with _lock, get_connection() as conn:
        conn.execute(
            """
            INSERT INTO prompts (nom, contenu, date) VALUES (?, ?, datetime('now'))
            ON CONFLICT(nom) DO UPDATE SET contenu = excluded.contenu, date = excluded.date
            """,
            (nom, contenu),
        )
    return get_prompt(nom)


def get_prompt(nom):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT id, nom, contenu, date FROM prompts WHERE nom = ?", (nom,)
        ).fetchone()
    return dict(row) if row else None


def get_default_prompt():
    """Retourne le prompt par défaut (nom='defaut') ou None."""
    return get_prompt("defaut")


def all_prompts():
    with get_connection() as conn:
        rows = conn.execute("SELECT id, nom, contenu, date FROM prompts ORDER BY nom").fetchall()
    return [dict(r) for r in rows]


def all_users():
    with get_connection() as conn:
        rows = conn.execute("SELECT username, password, role FROM users ORDER BY username").fetchall()
    return [dict(r) for r in rows]


def get_user(username):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT username, password, role FROM users WHERE username = ?", (username,)
        ).fetchone()
    return dict(row) if row else None


def add_user(username, password_hash, role="user"):
    with _lock, get_connection() as conn:
        conn.execute(
            "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, password_hash, role),
        )
    return get_user(username)


def get_users():
    """Alias de all_users()."""
    return all_users()


def user_exists(username):
    return get_user(username) is not None


def create_user(username, password_hash, role="user"):
    """Alias de add_user()."""
    return add_user(username, password_hash, role)


def update_user(username, **fields):
    allowed = {"password", "password_hash", "role"}
    updates = {k: v for k, v in fields.items() if k in allowed and v is not None}
    if "password_hash" in updates:
        updates["password"] = updates.pop("password_hash")
    if not updates:
        return get_user(username)
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    params = list(updates.values()) + [username]
    with _lock, get_connection() as conn:
        conn.execute(f"UPDATE users SET {set_clause} WHERE username = ?", params)
    return get_user(username)


def rename_user(old_username, new_username):
    """Renomme un utilisateur (met à jour la clé primaire username)."""
    old_username = (old_username or "").strip()
    new_username = (new_username or "").strip()
    if not old_username or not new_username:
        return None
    if old_username == new_username:
        return get_user(old_username)
    if user_exists(new_username):
        raise ValueError(f"Le compte '{new_username}' existe déjà.")
    with _lock, get_connection() as conn:
        cur = conn.execute(
            "UPDATE users SET username = ? WHERE username = ?",
            (new_username, old_username),
        )
    if cur.rowcount == 0:
        return None
    return get_user(new_username)


def delete_user(username):
    with _lock, get_connection() as conn:
        cur = conn.execute("DELETE FROM users WHERE username = ?", (username,))
    return cur.rowcount > 0


# Initialisation automatique à l'import
init_db()
