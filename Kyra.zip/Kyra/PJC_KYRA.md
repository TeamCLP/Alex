# KYRA — KYber Réunions & Applications

Site web Python (Flask) de l'équipe **PJC** du cluster **Paiement**, adossé à l'infrastructure évolutive **KYBER**.

## Vision

KYRA est un site multi-pages où chaque page expose une fonctionnalité s'appuyant sur les capacités de l'infrastructure KYBER :

1. **CR de réunions de suivi de projet** (phase 1 — priorité)
2. **Base documentaire & agent KYBER en chat** (phase 2)
3. **Espace personnel** (gestion des tags, profil) — à venir

---

## Suivi des demandes de création

| # | Demande | Statut |
|---|---------|--------|
| 1 | Page CR de réunion : injection d'une transcription, génération de 2 CR (retour mail + suivi Triskell) | ✅ Réalisé |
| 2 | CR « retour mail » : participants présents, date, objet, état d'avancement, reste à faire, actions en cours | ✅ Réalisé |
| 3 | CR « Triskell » : synthèse très succincte de 5 à 6 lignes | ✅ Réalisé |
| 4 | Sauvegarde des CR en JSON pour suivi de l'évolution des projets | ✅ Réalisé |
| 5 | Tag projet optionnel avec menu déroulant des tags existants + champ libre | ✅ Réalisé |
| 6 | Historique des CR consultable | ✅ Réalisé |
| 7 | Espace perso : gestion des tags (créer / modifier / supprimer) | ⬜ À faire |
| 8 | Page d'upload de documents vers bases virtuelles KYBER (commune et/ou personnelle) | ✅ Réalisé |
| 9 | Cloisonnement de la base personnelle : un utilisateur ne voit que ses documents (base unique multi-utilisateurs) | ✅ Réalisé |
| 10 | Agent KYBER en chat s'appuyant sur les bases commune / personnelle | ⬜ À faire |
| 11 | Authentification login/mdp + page admin de gestion des comptes (ajouter, modifier, supprimer, réinitialiser mdp, compte admin par défaut) | ✅ Réalisé |
| 12 | Base documentaire interrogeable par un agent : documents officiels publiés (consultation restreinte) + extension par notes et documents de travail non officiels | ⬜ À faire |
| 13 | Exploitation de Triskell pour extraire des vues automatiques inexistantes dans l'outil éditeur (à définir avec le GT) | ⬜ À faire |
| 14 | Calcul des coûts build/run à partir d'un formulaire d'infrastructure, selon la logique CAPRI (ou autre OCT à venir) | ⬜ À faire |
| 15 | Préparation automatique d'un CR de copro projet : plan de charge, reste à faire, actions en cours, synthèse Triskell avec historique | ⬜ À faire |

---

## Idées & pistes (notes CP)

### Base documentaire interrogeable par un agent

- Créer une **base de documents partageable par tous les chefs de projets**, interrogeable par un agent.
- Deux niveaux de contenu :
  - **documents officiels publiés** : consultation restreinte (lecture seule) ;
  - **notes chargées et documents de travail non officiels** : étendent la base de connaissance.
- Cette piste **recouvre et étend la phase 2** (bases commune / personnelle) : y intégrer la notion de documents officiels vs non officiels.

### Vues automatiques Triskell

- Voir avec le **GT** ce qui peut être exploité de **Triskell** pour extraire des **vues automatiques** non disponibles aujourd'hui (produit spécifique éditeur).

### Calcul des coûts build/run (logique CAPRI)

- Reprendre l'idée de **Jallal** (évoquée en weekly CP) : uploader une description d'infrastructure et faire calculer les **coûts de build** et **coûts de run** selon la logique **CAPRI** (ou autre OCT à venir), de façon simple.
- S'appuyer sur un **formulaire de base** à remplir : nombre d'environnements, lesquels, type de serveurs, puissance, zone réseau (3PG ou non) — puis l'outil effectue les calculs lui-même.

### CR de copro projet automatique

- Pouvoir déposer un **CR de réunion de copro projet** et obtenir automatiquement :
  - le **plan de charge** ;
  - le **reste à faire** ;
  - la **liste des actions en cours** ;
  - une **synthèse à coller dans Triskell**, avec si possible un **historique** de ce qui a été fait avant.

### Journal des évolutions

- Tenir un **journal des évolutions** du projet (le présent document et son tableau de suivi).

---

## Phase 1 — CR de réunions (réalisée)

- L'utilisateur colle une **transcription de réunion**.
- Il peut associer un **tag projet** (menu déroulant alimenté par les tags existants, ou saisie libre) — optionnel.
- KYBER génère deux CR :
  - **CR retour mail** : participants présents, date et objet, sections « État d'avancement », « Reste à faire », « Actions en cours ».
  - **CR Triskell** : 5-6 lignes très succinctes pour intégration dans l'outil de suivi.
- Les deux CR sont **stockés en JSON** (`data/cr_suivi.json`) horodatés, avec le tag projet, pour suivre l'évolution.
- Page **Historique** listant tous les CR enregistrés.

## Authentification & gestion des comptes (réalisée)

- Page de **login** (utilisateur / mot de passe) protégeant l'accès à l'ensemble du site.
- Comptes utilisateurs stockés dans `data/users.json`, avec un compte **admin / admin** créé par défaut.
- Page **Administration** (réservée aux admins) permettant de :
  - ajouter un compte utilisateur,
  - modifier un compte (login, rôle, mot de passe),
  - supprimer un compte,
  - réinitialiser le mot de passe d'un compte.
- Lien « Administration » et bouton de déconnexion affichés dans le menu uniquement pour les admins.

## Phase 2 — Base documentaire & agent KYBER (à venir)

- Page d'upload de documents, à injecter au choix dans :
  - la **base d'information commune** (partagée),
  - la **base d'information personnelle** (cloisonnée par utilisateur : une seule base, documents adressables uniquement par leur propriétaire).
- Consultation des données par un **agent KYBER** avec interface de **chat**.
- **Espace perso** : gestion des tags (création, modification, suppression).

## Lancement

```bash
pip install -r requirements.txt
python3 app.py
```

Puis ouvrir http://127.0.0.1:3000
