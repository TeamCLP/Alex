"""KYRA — KYber Réunions & Applications (équipe PJC, cluster Paiement).

Point d'entrée minimal : assemble les blueprints du package `kyra`
(auth, admin, documents, réunions, kyber) et lance le serveur.
"""
from flask import Flask, render_template

from kyra.auth import auth_bp
from kyra.admin import admin_bp
from kyra.documents import documents_bp
from kyra.reunions import reunions_bp
from kyra.kyber import kyber_bp

app = Flask(__name__)
app.secret_key = "kyra-secret-key-a-changer-en-production"

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(documents_bp)
app.register_blueprint(reunions_bp)
app.register_blueprint(kyber_bp)


@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    from kyra.common import ensure_data_dir, ensure_default_admin
    ensure_data_dir()
    ensure_default_admin()
    app.run(host="0.0.0.0", port=3000)
