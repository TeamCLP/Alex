/* Kyber Widget — bulle de chat autonome
 * Injecte un panneau de chat dans la page hôte et POST les messages
 * vers /kyber/invoke. Affiche le champ `reply` de la réponse JSON.
 */
(function () {
  'use strict';

  var ENDPOINT = '/kyber/invoke';

  /* ---------- Styles ---------- */
  var css = [
    '#kyber-widget{position:fixed;bottom:120px;left:20px;z-index:99999;display:flex;font-family:system-ui,sans-serif;}',
    '#kyber-toggle{width:48px;height:48px;border-radius:50%;border:none;background:#1a73e8;color:#fff;font-size:22px;line-height:1;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;padding:0;}',
    '#kyber-panel{display:none;flex-direction:column;position:absolute;bottom:56px;left:0;right:auto;transform:none;width:420px;height:480px;background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.25);overflow:hidden;z-index:99999;}',
    '#kyber-panel.open{display:flex;}',
    '#kyber-header{background:#1a73e8;color:#fff;padding:10px 14px;font-weight:600;}',
    '#kyber-messages{flex:1;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:8px;background:#f5f6fa;}',
    '.kyber-msg{max-width:80%;padding:8px 12px;border-radius:12px;font-size:14px;word-wrap:break-word;white-space:pre-wrap;}',
    '.kyber-msg.user{align-self:flex-end;background:#1a73e8;color:#fff;border-bottom-right-radius:2px;}',
    '.kyber-msg.bot{align-self:flex-start;background:#e8eaed;color:#202124;border-bottom-left-radius:2px;}',
    '.kyber-msg.error{align-self:flex-start;background:#fdecea;color:#b3261e;}',
    '#kyber-form{display:flex;border-top:1px solid #e0e0e0;}',
    '#kyber-input{flex:1;border:none;padding:12px;font-size:14px;outline:none;}',
    '#kyber-send{border:none;background:#1a73e8;color:#fff;padding:0 18px;cursor:pointer;font-size:14px;}'
  ].join('\n');

  var style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  /* ---------- DOM ---------- */
  var root = document.createElement('div');
  root.id = 'kyber-widget';
  root.innerHTML =
    '<div id="kyber-panel">' +
    '  <div id="kyber-header">KyberBot</div>' +
    '  <div id="kyber-messages"></div>' +
    '  <form id="kyber-form">' +
    '    <input id="kyber-input" type="text" placeholder="Votre message…" autocomplete="off" />' +
    '    <button id="kyber-send" type="submit">➤</button>' +
    '  </form>' +
    '</div>' +
    '<button id="kyber-toggle" title="KyberBot">💬</button>';
  (document.getElementById('kyber-root') || document.body).appendChild(root);

  var panel = root.querySelector('#kyber-panel');
  var messages = root.querySelector('#kyber-messages');
  var input = root.querySelector('#kyber-input');
  var form = root.querySelector('#kyber-form');
  var toggle = root.querySelector('#kyber-toggle');

  toggle.addEventListener('click', function () {
    panel.classList.toggle('open');
    if (panel.classList.contains('open')) {
      input.focus();
    }
  });

  function addMsg(text, cls) {
    var div = document.createElement('div');
    div.className = 'kyber-msg ' + cls;
    div.textContent = text;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
    return div;
  }

  /* ---------- Envoi vers /kyber/invoke ---------- */
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var text = input.value.trim();
    if (!text) return;
    input.value = '';
    addMsg(text, 'user');

    var pending = addMsg('…', 'bot');

    fetch(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ message: text })
    })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(function (data) {
        pending.textContent = (data && data.reply) ? data.reply : '(réponse vide)';
      })
      .catch(function (err) {
        pending.className = 'kyber-msg error';
        pending.textContent = 'Erreur : ' + err.message;
      });
  });
})();
