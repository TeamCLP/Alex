#!/usr/bin/env python3
"""Diagnostic : ouvre une session Flask authentifiee (admin/admin),
appelle /kyberbot et affiche le HTML rendu (inputs / boutons)."""
import re
import sys

sys.path.insert(0, ".")

from app import app  # noqa: E402


def main():
    with app.test_client() as client:
        # Authentification
        resp = client.post("/login", data={"username": "admin", "password": "admin"}, follow_redirects=True)
        if resp.status_code != 200:
            print(f"[!] Echec login: {resp.status_code}")
            sys.exit(1)
        print("[+] Login OK (admin/admin)")

        # Appel de /kyberbot
        resp = client.get("/kyberbot")
        print(f"[+] GET /kyberbot -> {resp.status_code}")
        html = resp.get_data(as_text=True)

        print("\n===== HTML rendu =====\n")
        print(html)

        print("\n===== Elements detectes =====")
        for tag in re.findall(r"<input[^>]*>", html, re.I):
            print("INPUT :", tag)
        for tag in re.findall(r"<button[^>]*>.*?</button>", html, re.I | re.S):
            print("BUTTON:", tag)


if __name__ == "__main__":
    main()
