#!/usr/bin/env python3
"""Diagnostic 404 : sonde les routes live de Kyra et affiche les codes HTTP.

Usage : python3 scripts/diag_404_check.py [base_url]
(base_url par défaut : http://127.0.0.1:3000)
"""
import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:3000"

CHECKS = [
    ("GET", "/kyberbot", None),
    ("POST", "/kyber/invoke", {"message": "ping diagnostic"}),
    ("GET", "/kyber/widget.js", None),
]


def probe(method, path, payload):
    url = BASE.rstrip("/") + path
    data = json.dumps(payload).encode() if payload else None
    req = urllib.request.Request(url, data=data, method=method)
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as e:
        return f"ERREUR ({e})"


def main():
    print(f"Sonde de diagnostic contre {BASE}\n")
    failures = 0
    for method, path, payload in CHECKS:
        code = probe(method, path, payload)
        ok = code == 200
        if not ok:
            failures += 1
        print(f"  [{ 'OK ' if ok else 'KO ' }] {method:4} {path:20} -> {code}")
    print()
    if failures:
        print(f"{failures} route(s) en échec : 404 ou autre erreur détectée.")
        sys.exit(1)
    print("Aucune 404 : toutes les routes répondent.")


if __name__ == "__main__":
    main()
