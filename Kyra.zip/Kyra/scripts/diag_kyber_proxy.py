#!/usr/bin/env python3
"""Diagnostic proxy pour l'endpoint KYBER /invoke.

Affiche les variables d'environnement proxy puis tente un POST minimal :
  1) sans aucun proxy
  2) avec le proxy d'entreprise
"""

import os
import sys

import requests

KYBER_INVOKE_URL = os.environ.get(
    "KYBER_INVOKE_URL",
    "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca/api/v1/deploy/81cf2da7-bdfb-47c6-96e5-f0601f16a0d8/invoke",
)

PROXY_ENV_VARS = ["KYBER_PROXY", "http_proxy", "https_proxy", "all_proxy"]


def show_proxy_env() -> dict:
    """Affiche et retourne les variables d'environnement proxy."""
    env = {}
    print("=== Variables d'environnement proxy ===")
    for var in PROXY_ENV_VARS:
        value = os.environ.get(var)
        env[var] = value
        display = value if value else "(non définie)"
        print(f"  {var} = {display}")
    print()
    return env


def try_post(label: str, proxies: dict | None, payload: dict | None = None, verify: bool = True) -> None:
    """Tente un POST minimal vers /invoke avec la configuration donnée."""
    if payload is None:
        payload = {"prompt": "ping de diagnostic"}
    print(f"--- Tentative : {label} ---")
    print(f"  URL      : {KYBER_INVOKE_URL}")
    print(f"  proxies  : {proxies if proxies else 'aucun'}")
    print(f"  payload  : {payload}")
    print(f"  verify   : {verify}")
    try:
        resp = requests.post(
            KYBER_INVOKE_URL,
            json=payload,
            proxies=proxies,
            verify=verify,
            timeout=15,
        )
        print(f"  Statut   : {resp.status_code}")
        body = resp.text[:300]
        print(f"  Réponse  : {body}{'...' if len(resp.text) > 300 else ''}")
    except requests.RequestException as exc:
        print(f"  ERREUR   : {exc}")
    print()


def main() -> int:
    env = show_proxy_env()

    # 1) Sans aucun proxy : on désactive aussi la lecture des variables d'env
    no_proxy = {"http": None, "https": None, "all": None}
    try_post("sans aucun proxy", proxies=no_proxy)

    # 1bis) Le 422 vient du corps de la requête : on teste plusieurs formats
    #        de payload courants pour identifier celui que Kyber accepte.
    payloads = {
        'prompt': {"prompt": "ping de diagnostic"},
        'input': {"input": "ping de diagnostic"},
        'question': {"question": "ping de diagnostic"},
        'message': {"message": "ping de diagnostic"},
        'langserve': {"input": {"question": "ping de diagnostic"}},
    }
    for name, payload in payloads.items():
        try_post(f"payload {name!r}", proxies=no_proxy, payload=payload)

    # 2) Avec le proxy d'entreprise (KYBER_PROXY, sinon http_proxy/https_proxy)
    corporate = env.get("KYBER_PROXY") or env.get("https_proxy") or env.get("http_proxy")
    if corporate:
        try_post(
            "avec le proxy d'entreprise",
            proxies={"http": corporate, "https": corporate},
        )
    else:
        print("--- Tentative : avec le proxy d'entreprise ---")
        print("  Aucun proxy d'entreprise détecté (KYBER_PROXY/http_proxy/https_proxy).")
        print()

    # 3) Sans vérification SSL : uniquement pour diagnostic, afin de confirmer
    #    qu'un éventuel échec vient bien de la validation du certificat
    #    (erreur « unable to get local issuer certificate »). Ne pas faire
    #    cela en production : la vérification SSL doit rester active.
    print("!! Tentative avec verify=False : UNIQUEMENT POUR DIAGNOSTIC !!")
    try_post(
        "sans vérification SSL (verify=False, diagnostic uniquement)",
        proxies={"http": None, "https": None, "all": None},
        verify=False,
    )

    print("Diagnostic terminé.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
