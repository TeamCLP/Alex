#!/usr/bin/env python3
"""Diagnostic des routes admin des clés API de Kyra.

Ouvre une session admin (login), puis :
  - GET /admin/api_keys
  - POST de création d'une clé
  - DELETE de la clé de diagnostic
Affiche statut HTTP + corps brut pour chaque appel.

Usage : python3 scripts/diag_apikeys.py [base_url] [user] [password]
Défaut : http://127.0.0.1:3000, admin / admin
"""
import sys
import requests

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:3000"
USER = sys.argv[2] if len(sys.argv) > 2 else "admin"
PASSWORD = sys.argv[3] if len(sys.argv) > 3 else "admin"

GET_ROUTES = ["/admin/api_keys"]
POST_ROUTES = ["/admin/api_keys"]


def show(label, resp):
    print(f"\n=== {label} ===")
    print(f"URL    : {resp.url}")
    print(f"Statut : {resp.status_code}")
    body = resp.text
    print(f"Corps  : {body[:2000]}")


def main():
    s = requests.Session()

    # 1) Login admin (essaie les variantes usuelles)
    logged = False
    for login_route in ["/login", "/auth/login", "/admin/login"]:
        r = s.post(BASE + login_route, data={"username": USER, "password": PASSWORD}, allow_redirects=False)
        print(f"POST {login_route} -> {r.status_code}")
        if r.status_code in (200, 302):
            logged = True
            break
    if not logged:
        print("!! Login impossible, on continue sans session.")

    # 2) GET sur les variantes de routes
    for route in GET_ROUTES:
        try:
            show(f"GET {route}", s.get(BASE + route, timeout=10))
        except Exception as e:
            print(f"\n=== GET {route} === ERREUR: {e}")

    # 3) POST de création d'une clé
    payload = {"service": "diag-key", "key": "xxx"}
    for route in POST_ROUTES:
        try:
            show(f"POST {route} (json)", s.post(BASE + route, json=payload, timeout=10))
        except Exception as e:
            print(f"\n=== POST {route} === ERREUR: {e}")

    # 4) DELETE de la clé de diagnostic
    try:
        show("DELETE /admin/api_keys/diag-key", s.delete(BASE + "/admin/api_keys/diag-key", timeout=10))
    except Exception as e:
        print(f"\n=== DELETE /admin/api_keys/diag-key === ERREUR: {e}")


if __name__ == "__main__":
    main()
