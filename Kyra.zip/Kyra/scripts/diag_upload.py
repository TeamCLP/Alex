#!/usr/bin/env python3
"""Diagnostic de l'upload de documents.

Connecte admin/admin via le client de test Flask, poste un fichier
vers /documents avec base=commune, puis affiche :
  - le code HTTP de la réponse,
  - les messages flash,
  - le contenu de data/documents.json.
"""
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402


def main():
    app.config["TESTING"] = True
    client = app.test_client()

    # 1) Connexion admin/admin
    resp = client.post("/login", data={"username": "admin", "password": "admin"},
                       follow_redirects=True)
    print(f"[login] HTTP {resp.status_code}")
    if resp.status_code != 200:
        print("Échec de connexion, arrêt du diagnostic.")
        return 1

    # 2) POST d'un fichier vers /documents
    data = {
        "base": "commune",
        "fichier": (io.BytesIO("contenu de test".encode("utf-8")), "diag_test.txt"),
    }
    resp = client.post("/documents", data=data, content_type="multipart/form-data",
                       follow_redirects=True)
    print(f"[upload] HTTP {resp.status_code}")

    # 3) Messages flash présents dans la page renvoyée
    html = resp.get_data(as_text=True)
    for marker in ("flash", "alert", "message"):
        if marker in html.lower():
            print(f"[flash] balise '{marker}' détectée dans la réponse")
    for line in html.splitlines():
        if "flash" in line.lower() or "alert" in line.lower():
            print("  " + line.strip()[:200])

    # 4) Contenu de data/documents.json
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "data", "documents.json")
    print(f"\n--- {path} ---")
    try:
        with open(path, "r", encoding="utf-8") as f:
            docs = json.load(f)
        print(json.dumps(docs, indent=2, ensure_ascii=False))
    except Exception as exc:
        print(f"Impossible de lire documents.json : {exc}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
