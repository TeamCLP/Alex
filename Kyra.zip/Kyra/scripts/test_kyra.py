#!/usr/bin/env python3
"""Script de test pour Kyra : utilise app.test_client() pour simuler
une session utilisateur et vérifier /kyberbot (formulaire de dialogue
avec l'API KYBER via /kyber/invoke)."""
import os
import re
import sys

# app.py se trouve dans Alex/Kyra, parent du répertoire de ce script
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import app  # noqa: E402


def main():
    client = app.test_client()
    errors = []

    # Simuler une session utilisateur (utilisateur connecté)
    with client.session_transaction() as sess:
        sess["user"] = "test_user"

    # GET /kyberbot
    resp = client.get("/kyberbot")
    body = resp.get_data(as_text=True)
    print(f"GET /kyberbot -> {resp.status_code} ({len(resp.data)} octets)")
    if resp.status_code != 200:
        errors.append(f"/kyberbot a renvoyé {resp.status_code}")
    else:
        print("  extrait:", " ".join(body.split())[:200])

    # Vérifier que /kyberbot utilise le formulaire de dialogue KyberBot
    if 'id="kyber-form"' not in body:
        errors.append("/kyberbot ne contient pas le formulaire #kyber-form")
    else:
        print("  formulaire #kyber-form présent : OK")

    if "fetch('/kyber/invoke'" not in body:
        errors.append("/kyberbot ne contient pas le fetch vers /kyber/invoke")
    else:
        print("  fetch vers /kyber/invoke présent : OK")

    # Vérifier que le widget KYBER proxyifié est bien embarqué
    # (accepte une query string éventuelle, ex. ?key=...)
    if not re.search(r'<script\s+src="/kyber/widget\.js(?:\?[^"]*)?">', body):
        errors.append(
            "/kyberbot ne contient pas le tag <script> du widget KYBER proxyifié"
        )
    else:
        print("  widget KYBER proxyifié présent : OK")

    if errors:
        print("\nERREURS DÉTECTÉES:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    print("\nTous les tests sont passés avec succès.")


if __name__ == "__main__":
    main()
