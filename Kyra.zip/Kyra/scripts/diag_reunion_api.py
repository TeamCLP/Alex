#!/usr/bin/env python3
"""Diagnostic : POST /reunion/api via app.test_client() avec session simulée.

Usage :
    python scripts/diag_reunion_api.py [chemin_fichier]

Si aucun chemin n'est fourni, le premier fichier .docx de uploads/ est utilisé.
"""
import os
import sys

# Permet l'exécution depuis scripts/ : importe app.py à la racine
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402


def pick_upload(explicit=None):
    if explicit:
        if not os.path.isfile(explicit):
            sys.exit(f"Fichier introuvable : {explicit}")
        return explicit
    updir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "uploads")
    for name in sorted(os.listdir(updir)):
        path = os.path.join(updir, name)
        if os.path.isfile(path) and name.lower().endswith(".docx"):
            return path
    sys.exit("Aucun fichier .docx trouvé dans uploads/")


def main():
    path = pick_upload(sys.argv[1] if len(sys.argv) > 1 else None)
    print(f"Fichier à envoyer : {path}")

    client = app.test_client()

    # Session simulée : injection directe de la session (méthode de
    # scripts/test_kyra.py), avec fallback admin/admin si la clé diffère.
    with client.session_transaction() as sess:
        sess["user"] = "diag"
        sess["username"] = "admin"
    try:
        resp = client.post("/login", data={"username": "admin", "password": "admin"},
                           follow_redirects=True)
        print(f"Login fallback admin/admin : statut {resp.status_code}")
    except Exception as exc:
        print(f"Login fallback ignoré : {exc}")

    with open(path, "rb") as fh:
        resp = client.post(
            "/reunion/api",
            data={"fichier": (fh, os.path.basename(path))},
            content_type="multipart/form-data",
            follow_redirects=False,
        )

    print(f"POST /reunion/api -> statut {resp.status_code}")
    body = resp.get_data(as_text=True)
    print("Réponse :")
    print(body[:2000])
    if resp.status_code == 200:
        print("OK : le prochain envoi devrait passer.")
    else:
        print("KO : inspecter le statut/réponse ci-dessus.")


if __name__ == "__main__":
    main()
