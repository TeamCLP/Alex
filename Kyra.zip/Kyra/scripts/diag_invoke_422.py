#!/usr/bin/env python3
"""Diagnostic 422 sur l'appel Kyber /invoke.

Teste plusieurs payloads (message court, message long type CR, avec/sans
Authorization) et affiche code de statut + corps complet de chaque réponse
pour identifier le champ exact exigé par l'API.

Usage : python scripts/diag_invoke_422.py [deploy_id]
Sans deploy_id, l'URL par défaut (kyra.kyber.KYBER_INVOKE_URL) est utilisée.
"""
import json
import os
import sys

import requests

# Réutilise la clé et l'URL par défaut chargés par l'application
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from kyra.kyber import _load_kyber_key, KYBER_INVOKE_URL
except ImportError:
    try:
        from kyra import _load_kyber_key, KYBER_INVOKE_URL
    except ImportError:
        _load_kyber_key = None
        KYBER_INVOKE_URL = None

BASE_URL = "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca"
DEFAULT_INVOKE_URL = (
    "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca"
    "/api/v1/deploy/81cf2da7-bdfb-47c6-96e5-f0601f16a0d8/invoke"
)


def get_invoke_url():
    # 1. Variable d'environnement, 2. URL par défaut de kyra.kyber (ou codée en dur),
    # 3. repli sur sys.argv[1]. Plus jamais d'input() (EOFError en non-interactif).
    url = os.environ.get("KYBER_INVOKE_URL") or KYBER_INVOKE_URL or DEFAULT_INVOKE_URL
    if url:
        return url
    deploy_id = sys.argv[1] if len(sys.argv) > 1 else ""
    if not deploy_id:
        print("[warn] Aucun deploy_id disponible (env, kyra.kyber ou argv).")
        sys.exit(1)
    return f"{BASE_URL}/api/v1/deploy/{deploy_id}/invoke"


def get_key():
    if _load_kyber_key is not None:
        try:
            return _load_kyber_key()
        except Exception as e:
            print(f"[warn] _load_kyber_key indisponible: {e}")
    return os.environ.get("KYBER_API_KEY")


CR_LONG = """Compte rendu de réunion de suivi du projet CVx2.

Participants : Alice, Bob, Charlie.

1. Avancement : le lot 1 est livré, le lot 2 est en cours de recette.
2. Risques : dépendance externe sur la plateforme Kyber, à surveiller.
3. Actions :
   - Alice : mettre à jour le planning (échéance 15/06).
   - Bob : préparer la démo client.
   - Charlie : rédiger la note d'architecture.

Prochaine réunion dans deux semaines.
"""


def payloads():
    short = {"message": "Bonjour, test de diagnostic."}
    long_msg = {"message": CR_LONG}
    variants = [
        ("message court, avec Authorization", short, True),
        ("message court, sans Authorization", short, False),
        ("message long (CR), avec Authorization", long_msg, True),
        ("message long (CR), sans Authorization", long_msg, False),
    ]
    # Variantes de nommage de champ courantes
    variants.append(("champ 'input', avec Authorization", {"input": "test"}, True))
    variants.append(("champ 'query', avec Authorization", {"query": "test"}, True))
    variants.append(("champ 'prompt', avec Authorization", {"prompt": "test"}, True))
    variants.append(("payload vide, avec Authorization", {}, True))
    return variants


def _post_with_ssl_fallback(url, json_payload, headers):
    """POST robuste : appel normal -> certifi -> verify=False sans proxy.

    Sur le modèle de kyra.kyber._request_with_ssl_fallback : chaque étape
    intercepte toute RequestException afin de révéler le vrai point de
    blocage (CA d'entreprise manquante, proxy...) et d'obtenir le corps
    réel des réponses 422.
    """
    try:
        return requests.post(url, json=json_payload, headers=headers, timeout=60)
    except requests.RequestException as sys_exc:
        print(f"[warn] étape 1/3 échec (magasin système) : {sys_exc}")
    try:
        import certifi
        print("[warn] étape 2/3 nouvelle tentative avec le bundle certifi")
        return requests.post(
            url, json=json_payload, headers=headers, timeout=60, verify=certifi.where()
        )
    except requests.RequestException as certifi_exc:
        print(f"[warn] étape 2/3 échec (certifi) : {certifi_exc}")
    print(
        "[warn] étape 3/3 dernier repli : verify=False et proxies désactivés. "
        "Définir REQUESTS_CA_BUNDLE vers le bundle CA d'entreprise pour un "
        "appel vérifié."
    )
    return requests.post(
        url,
        json=json_payload,
        headers=headers,
        timeout=60,
        verify=False,
        proxies={"http": None, "https": None, "all": None},
    )


def main():
    url = get_invoke_url()
    key = get_key()
    print(f"URL : {url}")
    print(f"Clé : {'présente (' + key[:6] + '...)' if key else 'ABSENTE'}")
    print("=" * 70)

    for label, payload, with_auth in payloads():
        headers = {"Content-Type": "application/json"}
        if with_auth and key:
            headers["Authorization"] = f"Bearer {key}"
        print(f"\n--- {label} ---")
        print(f"Payload: {json.dumps(payload, ensure_ascii=False)[:120]}...")
        try:
            r = _post_with_ssl_fallback(url, payload, headers)
            print(f"Statut : {r.status_code}")
            print(f"Réponse complète :")
            try:
                print(json.dumps(r.json(), indent=2, ensure_ascii=False))
            except ValueError:
                print(r.text)
        except requests.RequestException as e:
            print(f"Erreur requête : {e}")


if __name__ == "__main__":
    main()
