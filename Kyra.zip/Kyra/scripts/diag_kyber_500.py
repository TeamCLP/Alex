#!/usr/bin/env python3
"""Diagnostic HTTP 500 sur l'appel à Kyber : teste plusieurs payloads.

Usage : python3 scripts/diag_kyber_500.py
Doit être exécuté depuis la racine du projet.

Passe par le client de test Flask (POST /kyber/invoke) avec une session
simulée, car l'invocation vit désormais dans le blueprint `kyber.invoke`.
"""

import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from app import app
except ImportError as exc:
    print(f"Impossible d'importer app depuis app.py : {exc}")
    sys.exit(1)


PAYLOADS = {
    "message court": {"message": "Bonjour"},
    "message + session_id": {"message": "Bonjour", "session_id": "diag-001"},
    "payload complet /reunion": {
        "message": "Résume la réunion du jour",
        "session_id": "diag-001",
        "action": "reunion",
        "user": "diag",
    },
}


def main():
    app.config["TESTING"] = True
    client = app.test_client()
    with client.session_transaction() as session:
        # Session simulée pour satisfaire @login_required
        session["user"] = "diag"

    for label, payload in PAYLOADS.items():
        print(f"\n=== {label} ===")
        print(f"Payload : {json.dumps(payload, ensure_ascii=False)}")
        try:
            resp = client.post("/kyber/invoke", json=payload)
        except Exception as exc:  # noqa: BLE001
            print(f"ERREUR : {type(exc).__name__}: {exc}")
            continue
        print(f"Status  : {resp.status_code}")
        try:
            print(f"Corps   : {json.dumps(resp.get_json(), ensure_ascii=False, indent=2)}")
        except Exception:  # noqa: BLE001
            print(f"Corps   : {resp.get_data(as_text=True)}")


if __name__ == "__main__":
    main()
