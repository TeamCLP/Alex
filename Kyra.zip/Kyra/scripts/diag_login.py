#!/usr/bin/env python3
"""Diagnostic de login : affiche les hash de data/users.json et teste verify_password."""

import json
import sys
from pathlib import Path

# Permet l'exécution directe depuis scripts/
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from kyra.common import verify_password  # noqa: E402

USERS_FILE = ROOT / "data" / "users.json"
PASSWORDS = ["admin", "KYRA2026!"]


def check(user, password, stored):
    """Teste verify_password en gérant les deux ordres d'arguments possibles."""
    try:
        return verify_password(password, stored)
    except TypeError:
        return verify_password(user, password)


def main():
    if not USERS_FILE.exists():
        print(f"[ERREUR] Fichier introuvable : {USERS_FILE}")
        sys.exit(1)

    users = json.loads(USERS_FILE.read_text(encoding="utf-8"))
    # users.json peut être une liste ou un dict {username: {...}}
    if isinstance(users, dict):
        items = users.items()
    else:
        items = [(u.get("username", "?"), u) for u in users]

    for username, info in items:
        stored = info.get("password_hash") or info.get("hash") or info.get("password") if isinstance(info, dict) else info
        print(f"\n=== Utilisateur : {username} ===")
        print(f"  Hash stocké : {stored}")
        for pwd in PASSWORDS:
            try:
                ok = check(username, pwd, stored)
            except Exception as exc:
                ok = f"erreur ({exc})"
            print(f"  verify_password({pwd!r}) -> {ok}")


if __name__ == "__main__":
    main()
