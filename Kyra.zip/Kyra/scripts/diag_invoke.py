#!/usr/bin/env python3
"""Diagnostic : login Flask puis POST /kyber/invoke.

Utilise le client de test Flask (aucun serveur requis, aucun paquet
externe) : ouvre une session admin/admin puis appelle /kyber/invoke.
Affiche le statut HTTP et le corps BRUT de la réponse pour révéler
le format réellement renvoyé par KYBER.

Usage :
    python3 scripts/diag_invoke.py [message]
"""
import sys

sys.path.insert(0, ".")

from app import app  # noqa: E402


def main() -> int:
    message = " ".join(sys.argv[1:]) or "Bonjour Kyra, test d'invocation."

    with app.test_client() as client:
        # 1) Login Flask (récupère le cookie de session)
        print("[1] POST /login (user='admin')")
        resp = client.post("/login", data={"username": "admin", "password": "admin"})
        print(f"    -> statut {resp.status_code}")
        if resp.status_code not in (200, 302):
            print("    Login échoué, corps de la réponse:")
            print(resp.get_data(as_text=True)[:2000])
            return 1

        # 2) Invocation KYBER
        payload = {"message": message}
        print(f"[2] POST /kyber/invoke payload={payload!r}")
        resp = client.post("/kyber/invoke", json=payload)

        print(f"    -> statut HTTP : {resp.status_code}")
        print(f"    -> Content-Type: {resp.headers.get('Content-Type', '?')}")
        print("    -> corps brut de la réponse :")
        print("-" * 60)
        print(resp.get_data(as_text=True))
        print("-" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
