"""Diagnostic du proxy Kyber : à exécuter depuis Alex/Kyra :
    python3 scripts/diag_proxy.py
"""
import os
import sys

# Importe app comme test_kyra.py (racine du projet dans sys.path)
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import app  # noqa: E402


def main():
    print("=== Diagnostic proxy Kyber ===")

    # 1) Constantes éventuelles (KYBER_PROXY, KYBER_* ...)
    attrs = {
        a: getattr(app, a)
        for a in dir(app)
        if a.isupper() and ("KYBER" in a or "PROXY" in a)
    }
    if not attrs:
        print("!! Aucune constante KYBER_*/PROXY trouvée dans app.py")
        print("   -> app.py ne contient probablement pas le code du proxy.")
    else:
        for a, v in sorted(attrs.items()):
            print(f"{a} = {v!r}")

    # 2) Fonctions de récupération et de réécriture
    for name in (
        "_fetch_kyber_widget",
        "_fetch_kyber_public",
        "_kyber_rewrite_html",
        "_kyber_rewrite_js",
        "_widget_key_snippet",
    ):
        fn = getattr(app, name, None)
        if fn is None:
            print(f"{name} -> ABSENT de app.py")
            continue
        try:
            contenu, err = fn()
            if contenu:
                print(f"{name} -> OK ({len(contenu)} octets)")
            else:
                print(f"{name} -> ECHEC : {err}")
        except Exception as e:  # noqa: BLE001
            print(f"{name} -> EXCEPTION : {e!r}")

    cle = getattr(app, "KYBER_ACCESS_KEY", "")
    print("Clé d'accès configurée :", "oui" if cle else "non")

    # 2bis) Diagnostic CORS : origine autorisée ? préflight OK ?
    client = app.app.test_client()
    origines = os.environ.get("AB_CORS_ORIGINS", "")
    print("AB_CORS_ORIGINS (env) :", origines or "(non défini)")
    origine_test = "http://127.0.0.1:3000"
    for route in ("/kyber/chat", "/kyber/public"):
        try:
            resp = client.options(
                route,
                headers={
                    "Origin": origine_test,
                    "Access-Control-Request-Method": "POST",
                },
            )
            acao = resp.headers.get("Access-Control-Allow-Origin")
            print(
                f"OPTIONS {route} (Origin: {origine_test}) -> HTTP {resp.status_code}, "
                f"Access-Control-Allow-Origin: {acao or 'ABSENT'}"
            )
            if resp.status_code >= 400 or not acao:
                print(
                    "   -> Origine non autorisée côté Kyber : "
                    f"ajoutez {origine_test} à AB_CORS_ORIGINS."
                )
        except Exception as e:  # noqa: BLE001
            print(f"OPTIONS {route} -> EXCEPTION : {e!r}")

    # 3) Ce que voit réellement la page kyberbot
    for route in ("/kyber/public", "/kyber/widget", "/kyber/widget.js", "/kyber/widget-status", "/kyber/chat"):
        try:
            resp = client.get(route, headers={"Origin": "http://127.0.0.1:3000"})
            body = resp.get_data()
            print(f"GET {route} -> HTTP {resp.status_code} ({len(body)} octets)")
            if resp.status_code != 200:
                print("   corps :", body[:200])
            elif route.startswith("/kyber/widget") and not route.endswith("-status"):
                print("   tête du script :", body[:120])
        except Exception as e:  # noqa: BLE001
            print(f"GET {route} -> EXCEPTION : {e!r}")


if __name__ == "__main__":
    main()
