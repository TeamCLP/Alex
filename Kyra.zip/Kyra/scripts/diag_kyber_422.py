#!/usr/bin/env python3
"""Diagnostic 422 Kyber : teste plusieurs variantes de payload pour
révéler le champ attendu par l'API /invoke.

Usage : python scripts/diag_kyber_422.py [message]
"""
import json
import os
import sys

import certifi
import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from kyra.kyber import _load_kyber_key

KYBER_INVOKE_URL = os.environ.get(
    "KYBER_INVOKE_URL",
    "https://kyber-frontend-kyber-agent-clp-dev.apps.dev.ocp.cagip.group.gca/api/v1/deploy/81cf2da7-bdfb-47c6-96e5-f0601f16a0d8/invoke",
)


def main():
    message = " ".join(sys.argv[1:]) or "Bonjour, test de diagnostic."
    api_key = _load_kyber_key()
    if not api_key:
        print("[!] Aucune clé Kyber trouvée (_load_kyber_key).")
        sys.exit(1)

    session_id = "diag-422"
    payloads = [
        {"message": message},
        {"prompt": message},
        {"input": message},
        {"question": message},
        {"message": message, "session_id": session_id},
        {"prompt": message, "session_id": session_id},
        {"input": message, "session_id": session_id},
        {"question": message, "session_id": session_id},
        {"query": message},
        {"text": message},
        {"content": message},
        {"inputs": {"message": message}},
        {"messages": [{"role": "user", "content": message}]},
    ]

    for i, payload in enumerate(payloads, 1):
        print(f"\n=== Test {i}/{len(payloads)} : {json.dumps(payload, ensure_ascii=False)} ===")
        try:
            # Appel direct : magasin système -> certifi -> verify=False
            try:
                resp = requests.post(
                    KYBER_INVOKE_URL,
                    json=payload,
                    headers={"Authorization": f"Bearer {api_key}"},
                    timeout=30,
                )
            except requests.RequestException:
                try:
                    resp = requests.post(
                        KYBER_INVOKE_URL,
                        json=payload,
                        headers={"Authorization": f"Bearer {api_key}"},
                        timeout=30,
                        verify=certifi.where(),
                    )
                except requests.RequestException:
                    resp = requests.post(
                        KYBER_INVOKE_URL,
                        json=payload,
                        headers={"Authorization": f"Bearer {api_key}"},
                        timeout=30,
                        verify=False,
                        proxies={"http": None, "https": None, "all": None},
                    )
            print(f"HTTP {resp.status_code}")
            print(resp.text[:2000])
        except Exception as exc:
            print(f"[!] Erreur : {exc}")


if __name__ == "__main__":
    main()
