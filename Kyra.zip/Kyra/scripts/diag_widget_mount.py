#!/usr/bin/env python3
"""Diagnostic du montage du widget Kyber.

Récupère /kyber/widget-page et /kyber/widget.js sur http://127.0.0.1:3000,
affiche les 80 premières lignes du widget.js, y recherche l'ID/élément DOM
monté (getElementById, querySelector, kyber-root, appendChild) et signale
toute erreur HTTP ou JS visible.
"""

import re
import sys
import urllib.request

BASE_URL = "http://127.0.0.1:3000"
WIDGET_JS_URL = BASE_URL + "/kyber/widget.js"
WIDGET_PAGE_URL = BASE_URL + "/kyber/widget-page"

MOUNT_PATTERNS = [
    r"getElementById\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
    r"querySelector\s*\(\s*['\"]([^'\"]+)['\"]\s*\)",
    r"kyber-root",
    r"appendChild",
]

JS_ERROR_PATTERNS = [
    r"Uncaught\s+\w+",
    r"SyntaxError",
    r"ReferenceError",
    r"TypeError",
    r"is not defined",
    r"null is not an object",
]


def fetch(url):
    """Récupère une URL, retourne (contenu, erreur)."""
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace"), None
    except Exception as exc:  # noqa: BLE001
        return None, exc


def main():
    print("=== Diagnostic montage widget Kyber ===")
    print(f"Base: {BASE_URL}\n")

    # --- Page du widget ---
    print(f"[1] GET {WIDGET_PAGE_URL}")
    page, err = fetch(WIDGET_PAGE_URL)
    if err:
        print(f"    ERREUR HTTP: {err}")
    else:
        print(f"    OK ({len(page)} octets)")
        if re.search(r"<title>([^<]*)</title>", page):
            print(f"    Titre: {re.search(r'<title>([^<]*)</title>', page).group(1)}")
    print()

    # --- widget.js ---
    print(f"[2] GET {WIDGET_JS_URL}")
    js, err = fetch(WIDGET_JS_URL)
    if err:
        print(f"    ERREUR HTTP: {err}")
        sys.exit(1)
    print(f"    OK ({len(js)} octets)\n")

    lines = js.splitlines()
    print("--- 80 premières lignes de widget.js ---")
    for i, line in enumerate(lines[:80], 1):
        print(f"{i:4d} | {line}")
    print(f"--- ({len(lines)} lignes au total) ---\n")

    # --- Recherche des points de montage DOM ---
    print("[3] Recherche des points de montage DOM:")
    found = False
    for pattern in MOUNT_PATTERNS:
        for match in re.finditer(pattern, js):
            found = True
            line_no = js[: match.start()].count("\n") + 1
            print(f"    L{line_no}: {match.group(0)}")
    if not found:
        print("    ATTENTION: aucun point de montage DOM détecté "
              "(getElementById / querySelector / kyber-root / appendChild).")
    print()

    # --- Erreurs JS visibles dans le code ---
    print("[4] Erreurs JS visibles dans le code:")
    errors_found = False
    for pattern in JS_ERROR_PATTERNS:
        for match in re.finditer(pattern, js):
            errors_found = True
            line_no = js[: match.start()].count("\n") + 1
            print(f"    L{line_no}: {match.group(0)}")
    if not errors_found:
        print("    Aucune erreur JS visible dans le code source.")

    print("\n=== Fin du diagnostic ===")


if __name__ == "__main__":
    main()
