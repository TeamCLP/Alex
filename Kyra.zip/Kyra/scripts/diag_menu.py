#!/usr/bin/env python3
"""Diagnostic : vérifie que le lien « Mes documents » est présent dans le menu
de chaque page rendue (/, /reunion, /historique, /documents, /kyberbot).

Usage : python scripts/diag_menu.py
"""
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402

PAGES = ["/", "/reunion", "/historique", "/documents", "/kyberbot"]

# Motifs possibles du lien vers les documents dans le menu
PATTERNS = [
    re.compile(r"<a\s[^>]*href\s*=\s*['\"]/documents['\"][^>]*>.*?Mes\s+documents.*?</a>", re.I | re.S),
    re.compile(r"Mes\s+documents", re.I),
]


def check(page: str, html: str) -> bool:
    ok = any(p.search(html) for p in PATTERNS)
    status = "OK  " if ok else "MISS"
    print(f"[{status}] {page:<12} -> lien 'Mes documents' {'présent' if ok else 'ABSENT'}")
    if not ok:
        # Affiche les <a> du rendu pour aider au debug
        links = re.findall(r"<a\s[^>]*href\s*=\s*['\"]([^'\"]+)['\"][^>]*>(.*?)</a>", html, re.I | re.S)
        print(f"        ({len(links)} liens trouvés :)")
        for href, text in links[:20]:
            label = re.sub(r"<[^>]+>", "", text).strip()
            print(f"        - {href!r} : {label!r}")
    return ok


def main() -> int:
    app.config["TESTING"] = True
    client = app.test_client()

    # Connexion préalable : sans session, chaque page est redirigée vers
    # /login et le rendu ne contient que le lien « Accueil ».
    resp = client.post("/login", data={"username": "admin", "password": "admin"},
                       follow_redirects=True)
    if resp.status_code != 200 or b"/logout" not in resp.get_data():
        print("[FAIL] Impossible de connecter le client de test (admin/admin)")
        return 1
    print("[OK  ] Connexion du client de test (admin/admin)")

    all_ok = True
    for page in PAGES:
        resp = client.get(page, follow_redirects=True)
        if resp.status_code != 200:
            print(f"[FAIL] {page:<12} -> HTTP {resp.status_code}")
            all_ok = False
            continue
        html = resp.get_data(as_text=True)
        if not check(page, html):
            all_ok = False
    print("\nRésultat :", "toutes les pages OK" if all_ok else "au moins une page en échec")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
