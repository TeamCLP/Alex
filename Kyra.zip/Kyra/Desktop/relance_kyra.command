#!/bin/sh
# relance_kyra.command — Relance du serveur Kyra (double-cliquer sur macOS)
# Rendre exécutable : chmod +x ~/Desktop/relance_kyra.command

# Répertoire du projet Kyra : déduit de l'emplacement de ce script
KYRA_DIR="$HOME/Library/CloudStorage/OneDrive-GroupeCréditAgricole/PRO/DEV IA/PJC/Alex/Kyra"

LOG_FILE="$KYRA_DIR/kyber_server.log"
URL="http://127.0.0.1:3000"

echo "==> Répertoire du projet : $KYRA_DIR"

if [ ! -f "$KYRA_DIR/app.py" ]; then
    echo "ERREUR : app.py introuvable dans $KYRA_DIR"
    echo "Ajustez la variable KYRA_DIR en tête de ce script."
    exit 1
fi

cd "$KYRA_DIR" || exit 1

echo "==> Arrêt des anciens processus 'python3 app.py'..."
pkill -f "python3 app.py" 2>/dev/null
sleep 2

echo "==> Démarrage du serveur en arrière-plan..."
nohup python3 app.py >> "$LOG_FILE" 2>&1 &

echo "==> Attente du démarrage..."
sleep 5

if curl -s -o /dev/null --max-time 10 "$URL"; then
    echo ""
    echo "✅ Serveur Kyra relancé avec succès : $URL"
    echo "   (log : $LOG_FILE)"
else
    echo ""
    echo "❌ Échec : le serveur ne répond pas sur $URL"
    echo "   Ouverture du log pour diagnostic..."
    open -e "$LOG_FILE" 2>/dev/null || tail -n 50 "$LOG_FILE"
fi
